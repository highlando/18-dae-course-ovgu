function [t,x]=expl_euler(f,xinit,tspan)
% Number of time steps 
n=numel(tspan);
% Stepsizes in time grid 
h=diff(tspan);
% Initialization of x and y as column vectors
x=[xinit; zeros(n-1,numel(xinit))]; t=[tspan(1); zeros(n-1,1)];
% Calculation of x and y
for i=1:n-1
t(i+1)=t(i)+h(i);
x(i+1,:)=x(i,:)+h(i)*f(t(i),x(i,:));
end
end