%% (a)
clear all
close all
clc

E = @(t) [-t t*t; -1 t];
A = @(t) [-1 0; 0 -1];
f = @(t) [0; 0];
I = [0 10];
N = 600;
tspan = linspace(I(1),I(2),N);
xinit = [0 1];

[t,X] = impl_euler(E,A,f,tspan,xinit);

% DAE = @(t,x) (A(t)*x + f(t));
% options = odeset('Mass',E,'MStateDependence','none');%,'MassSingular','maybe'
% [t2,x2]=ode15s(DAE,tspan,xinit,options);

figure(1)
plot(t,X,'.-')
title(['N = ',num2str(N)])
xlabel('t')
ylabel('x_1,x_2')
% hold on
% plot(t2,x2,'.-')

for k=1:N
error(k,:)=[-1 t(k);0 0]*X(k,:)';
end
figure(2)
plot(t,error)
title(['N = ',num2str(N)])
xlabel('t')
ylabel('error')
keyboard
