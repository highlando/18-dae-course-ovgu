%% (c)
clear all
close all
clc
E = @(t) [1 1; 0 0];
A = @(t) [0 0; 0 -1];
f = @(t) [exp(t) + cos(t); exp(t)];
I = [0 10];
N = 1000;
tspan = linspace(I(1),I(2),N);
xinit = [2 -1];
[t,X] = impl_euler(E,A,f,tspan,xinit);

DAE = @(t,x) (A(t)*x + f(t));
options = odeset('Mass',E,'MStateDependence','none','MassSingular','maybe');%
[t2,x2]=ode15s(DAE,tspan,xinit,options);

figure(1)
plot(t,X,'.-')
hold on
plot(t2,x2,'o-')
title(['N = ',num2str(N)])
xlabel('t')
ylabel('x_1,x_2')


figure(2)
plot(t,x2-X)
title(['N = ',num2str(N)])
xlabel('t')
ylabel('error')
