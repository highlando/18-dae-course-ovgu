function [t,X] = impl_euler(E,A,f,tspan,xinit)

% Number of time steps 
n=numel(tspan);
% Stepsizes in time grid 
h=diff(tspan);

F = @(t,x,y) (E(t)-h(1)*A(t))*x - E(t)*y - h(1)*f(t);
t0 = min(tspan);
 
X = zeros(n,2);
t = zeros(n,1);
 
X(1,:) = xinit;
t(1) = t0;
x0 = [0;0];
 
for k=2:n
    t(k) = t0 + (k-1)*h(1);
    X(k,:) = fsolve(@(x) F(t(k),x,X(k-1,:)'),x0);
end
 
 
end