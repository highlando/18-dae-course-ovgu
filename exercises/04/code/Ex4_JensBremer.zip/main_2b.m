%% (b)
clear all
close all
clc
E = @(t) [0 0; 1 -1];
A = @(t) [-1 t; 0 0];
f = @(t) [sin(t); cos(t)];
I = [0 10];%[pi/2 10];%
N = 1000;
tspan = linspace(I(1),I(2),N);
xinit = [0 0];%[1 0];%
[t,X] = impl_euler(E,A,f,tspan,xinit);

DAE = @(t,x) (A(t)*x + f(t));
options = odeset('Mass',E,'MStateDependence','none','MassSingular','maybe');%
[t2,x2]=ode15s(DAE,tspan,xinit,options);

figure(1)
plot(t,X,'.-')
hold on
plot(t2,x2,':')
title(['N = ',num2str(N)])
xlabel('t')
ylabel('x_1,x_2')

for k=1:N
error(k,:)=[-1 t(k);0 -1]*X(k,:)' + [sin(t(k));0];
end
figure(2)
plot(t,error)
title(['N = ',num2str(N)])
xlabel('t')
ylabel('error')


