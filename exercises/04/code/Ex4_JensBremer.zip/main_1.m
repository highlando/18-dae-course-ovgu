clear all
close all
clc

f=@(t,x) [exp(t)*x(2), -exp(t)*x(1)];
xinit= [sin(1) cos(1)];


for k=30
tspan=0:3/2^k:3;
[tsol,xsol]=expl_euler(f,xinit,tspan);

%semilogy(tsol,xsol)

plot(tsol,xsol,'.-')
title(['k = ',num2str(k)])
xlabel('t')
ylabel('x_1,x_2')
keyboard
end
